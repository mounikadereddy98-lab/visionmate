
package com.example.visionmate

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.widget.Button
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.objects.ObjectDetection
import com.google.mlkit.vision.objects.defaults.ObjectDetectorOptions
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var previewView: PreviewView
    private lateinit var statusText: TextView
    private lateinit var cameraExecutor: ExecutorService
    private lateinit var tts: TextToSpeech

    private val detector by lazy {
        ObjectDetection.getClient(
            ObjectDetectorOptions.Builder()
                .setDetectorMode(ObjectDetectorOptions.STREAM_MODE)
                .enableClassification()
                .build()
        )
    }

    private val textRecognizer by lazy {
        TextRecognition.getClient(
            TextRecognizerOptions.DEFAULT_OPTIONS
        )
    }

    private var running = false
    private var signboardMode = false
    private var ttsReady = false
    private var lastSpoken = ""
    private var lastSpeechTime = 0L
    private var lastOcrTime = 0L

    private val cameraPermission =
        registerForActivityResult(
            ActivityResultContracts.RequestPermission()
        ) { granted ->
            if (granted) {
                startCamera()
            } else {
                showStatus("కెమెరా అనుమతి ఇవ్వండి")
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        previewView = findViewById(R.id.previewView)
        statusText = findViewById(R.id.statusText)
        cameraExecutor = Executors.newSingleThreadExecutor()
        tts = TextToSpeech(this, this)

        findViewById<Button>(R.id.startButton).setOnClickListener {
            signboardMode = false
            running = true
            checkCameraPermission()
        }

        findViewById<Button>(R.id.readButton).setOnClickListener {
            signboardMode = true
            running = true
            checkCameraPermission()
        }

        findViewById<Button>(R.id.stopButton).setOnClickListener {
            running = false
            signboardMode = false
            showStatus("సహాయం ఆపబడింది")
            speak("సహాయం ఆపబడింది")

            val future = ProcessCameraProvider.getInstance(this)
            future.addListener({
                runCatching { future.get().unbindAll() }
            }, ContextCompat.getMainExecutor(this))
        }

        findViewById<Button>(R.id.navButton).setOnClickListener {
            speak("నడక మార్గం కోసం గూగుల్ మ్యాప్స్ తెరవబడుతుంది")
            val intent = Intent(
                Intent.ACTION_VIEW,
                Uri.parse(
                    "https://www.google.com/maps/dir/?api=1&travelmode=walking"
                )
            )
            startActivity(intent)
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts.setLanguage(Locale("te", "IN"))
            ttsReady =
                result != TextToSpeech.LANG_MISSING_DATA &&
                        result != TextToSpeech.LANG_NOT_SUPPORTED

            if (!ttsReady) {
                showStatus(
                    "ఫోన్‌లో Telugu Text-to-Speech voice ఇన్‌స్టాల్ చేయండి"
                )
            }
        }
    }

    private fun checkCameraPermission() {
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.CAMERA
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            startCamera()
        } else {
            cameraPermission.launch(Manifest.permission.CAMERA)
        }
    }

    private fun startCamera() {
        showStatus("కెమెరా ప్రారంభమవుతోంది...")

        val future = ProcessCameraProvider.getInstance(this)

        future.addListener({
            try {
                val provider = future.get()

                val preview = Preview.Builder().build()
                preview.setSurfaceProvider(previewView.surfaceProvider)

                val analysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(
                        ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST
                    )
                    .build()

                analysis.setAnalyzer(cameraExecutor) { proxy ->
                    if (running) {
                        analyzeFrame(proxy)
                    } else {
                        proxy.close()
                    }
                }

                provider.unbindAll()

                provider.bindToLifecycle(
                    this,
                    CameraSelector.DEFAULT_BACK_CAMERA,
                    preview,
                    analysis
                )

                showStatus("కెమెరా ప్రారంభమైంది. పరిసరాలను చూపండి.")

                if (signboardMode) {
                    speak("సైన్ బోర్డును కెమెరాకు చూపించండి")
                } else {
                    speak("సహాయం ప్రారంభమైంది")
                }

            } catch (e: Exception) {
                showStatus("కెమెరా లోపం: ${e.localizedMessage}")
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun analyzeFrame(proxy: ImageProxy) {
        val mediaImage = proxy.image

        if (mediaImage == null) {
            proxy.close()
            return
        }

        val image = InputImage.fromMediaImage(
            mediaImage,
            proxy.imageInfo.rotationDegrees
        )

        if (signboardMode) {
            readSignboard(image, proxy)
        } else {
            detectObjects(image, proxy)
        }
    }

    private fun detectObjects(
        image: InputImage,
        proxy: ImageProxy
    ) {
        detector.process(image)
            .addOnSuccessListener { objects ->
                if (objects.isEmpty()) {
                    showStatus("వస్తువులు గుర్తించబడలేదు")
                    return@addOnSuccessListener
                }

                val width = proxy.width.toFloat().coerceAtLeast(1f)

                val messages = objects
                    .sortedByDescending {
                        it.boundingBox.width() *
                                it.boundingBox.height()
                    }
                    .take(2)
                    .map { obj ->
                        val center =
                            obj.boundingBox.centerX().toFloat() / width

                        val direction = when {
                            center < 0.38f -> "ఎడమవైపు"
                            center > 0.62f -> "కుడివైపు"
                            else -> "ముందు"
                        }

                        val label =
                            obj.labels.firstOrNull()?.text ?: "వస్తువు"

                        "$direction ${toTelugu(label)}"
                    }
                    .distinct()

                val message = messages.joinToString(". ")
                showStatus("గుర్తించినవి: $message")
                speakWithDelay(message)
            }
            .addOnFailureListener {
                showStatus("వస్తువులను గుర్తించడంలో సమస్య")
            }
            .addOnCompleteListener {
                proxy.close()
            }
    }

    private fun readSignboard(
        image: InputImage,
        proxy: ImageProxy
    ) {
        val now = System.currentTimeMillis()

        if (now - lastOcrTime < 1200) {
            proxy.close()
            return
        }

        lastOcrTime = now

        textRecognizer.process(image)
            .addOnSuccessListener { result ->
                val text = result.text.trim()

                if (text.isNotEmpty()) {
                    showStatus("బోర్డు వచనం: $text")
                    speakWithDelay("బోర్డుపై ఉన్న వచనం. $text", 3000)
                } else {
                    showStatus("వచనం కనిపించలేదు. బోర్డును స్పష్టంగా చూపండి")
                }
            }
            .addOnFailureListener {
                showStatus("సైన్ బోర్డు చదవలేకపోయాను")
            }
            .addOnCompleteListener {
                proxy.close()
            }
    }

    private fun toTelugu(label: String): String {
        return when (label.lowercase(Locale.ROOT)) {
            "person" -> "వ్యక్తి ఉన్నారు"
            "car" -> "కారు ఉంది"
            "bicycle" -> "సైకిల్ ఉంది"
            "motorcycle" -> "మోటార్ సైకిల్ ఉంది"
            "bus" -> "బస్సు ఉంది"
            "truck" -> "ట్రక్కు ఉంది"
            "dog" -> "కుక్క ఉంది"
            "cat" -> "పిల్లి ఉంది"
            "chair" -> "కుర్చీ ఉంది"
            "bottle" -> "బాటిల్ ఉంది"
            "traffic light" -> "ట్రాఫిక్ లైట్ ఉంది"
            "stop sign" -> "స్టాప్ బోర్డు ఉంది"
            "backpack" -> "బ్యాగ్ ఉంది"
            else -> "వస్తువు ఉంది"
        }
    }

    private fun speakWithDelay(
        message: String,
        interval: Long = 1800
    ) {
        val now = System.currentTimeMillis()

        if (now - lastSpeechTime < interval) return
        if (message == lastSpoken && now - lastSpeechTime < 4000) return

        lastSpoken = message
        lastSpeechTime = now
        speak(message)
    }

    private fun speak(message: String) {
        if (ttsReady) {
            tts.speak(
                message,
                TextToSpeech.QUEUE_FLUSH,
                null,
                "visionmate_tts"
            )
        }
    }

    private fun showStatus(message: String) {
        runOnUiThread {
            statusText.text = message
        }
    }

    override fun onDestroy() {
        super.onDestroy()

        if (::cameraExecutor.isInitialized) {
            cameraExecutor.shutdown()
        }

        if (::tts.isInitialized) {
            tts.stop()
            tts.shutdown()
        }

        if (running) {
            runCatching { detector.close() }
        }

        runCatching { textRecognizer.close() }
    }
}
